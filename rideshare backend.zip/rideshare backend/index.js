// --------------------------------------------------------
    // Pull in the libraries
    const app = require('express')()
    const bodyParser = require('body-parser')
    const config = require('/Users/lorenzo/Desktop/rideshare/node_modules/config-js')
    const Pusher = require('pusher')
    const pusher = new Pusher({
        appId: '918423',
        key: 'db0bf15058e78e7046be',
        secret: '738b6c568a7742b098f8',
        cluster: 'us2',
        encrypted: true
    })    // --------------------------------------------------------
    
    // In-memory database
    let rider = null
    let driver = null
    let user_id = null
    let status = "Neutral"  
    
   
    
    // Express Middlewares
    app.use(bodyParser.json())
    app.use(bodyParser.urlencoded({extended: false}))    // --------------------------------------------------------
    // Helpers
        function uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }   

     // --------------------------------------------------------
    // Routes
    // --------------------------------------------------------    
    // ----- Rider --------------------------------------------    
    


        app.get('/status', (req, res) => res.json({ status }))     

        app.get('/request', (req, res) => res.json(driver))



        
 
        // server will grab this information from my app 
       

        app.post('/request', (req, res) => {
        user_id = req.body.user_id
        status = "Searching"
        rider = { name: "Lorenzo", longitude: 35.8462, latitude: -86.3693}        
        pusher.trigger('cabs', 'status-update', { status, rider })
        res.json({ status: true }) 
        
        })
        



        app.delete('/request', (req, res) => {
        driver = null
        status = "Neutral"
        pusher.trigger('cabs', 'status-update', { status })
        res.json({ status: true })
    })    
   

    // ----- Driver ------------------------------------------    
        app.get('/pending-rider', (req, res) => res.json(rider))    

        app.post('/status', (req, res) => {
        status = req.body.status       

         if (status == "EndedTrip" || status == "Neutral") {
            rider = driver = null
        } else {
            driver = { name: "John Doe" }
        }        


        pusher.trigger('cabs', 'status-update', { status, driver })
        res.json({ status: true })
    })    

    // ----- Misc ---------------------------------------------    
    app.get('/', (req, res) => res.json({ status: "success" }))    // --------------------------------------------------------
    // Serve application
     app.listen(4000, _ => console.log('App listening on port 4000!'))
     console.log()


















